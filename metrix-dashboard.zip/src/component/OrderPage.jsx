import React from "react";
import Order from "./Orders";



const OrderPage = () => {
    return(
            <Order />  
    )
}

export default OrderPage